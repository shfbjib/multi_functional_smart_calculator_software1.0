#include "tips.h"
#include "ui_tips.h"
#include "pgcalculator.h"
#include <QTextEdit>

Tips::Tips(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Tips)
{
    ui->setupUi(this);
    /*设置tips窗口的属性*/
    this->setFixedSize(340,500);  //设置tips窗口为固定大小
    this->setWindowTitle("Tips");  //设置窗口标题
    this->setWindowIcon(QIcon(":/images/Icon.jpeg"));  //更换窗口图标
    ui->textEdit->setReadOnly(true);  //设置文本框显示时为只读模式
    ui->textEdit->setStyleSheet("QTextEdit { background: transparent; }");  //设置背景为透明色
    ui->textEdit->setFrameShape(QFrame::NoFrame); // 删除边框
    /*设置背景图*/
    this->setAutoFillBackground(true);  //允许绘制
    QPixmap background=QPixmap(":/images/blackboard.png").scaled(this->size());  //创建图片控件
    QPalette palette;
    palette.setBrush(QPalette::Window,QBrush(background));  //设置调色板的窗口背景为指定图片
    this->setPalette(palette);  //将调色板应用到当前窗口
    this->show();  //显示tips窗口
    /*设置程序员福利按钮的属性*/
    ui->welfare->setStyleSheet("QPushButton{background-color: rgb(242, 242, 242);color:rgb(10,10,10);}");  //设置福利按钮的背景颜色和文本颜色
    ui->welfare->setFixedSize(111,31);  //设置福利按钮固定大小
}

Tips::~Tips()
{
    delete ui;
}

/*定义转换到程序员计算器的槽函数*/
void Tips::on_welfare_clicked()
{
    PgCalculator* pgcalc=new PgCalculator;  //创建程序员计算器
    pgcalc->show();  //显示程序员计算器窗口
    this->hide();  //隐藏tips窗口
}

