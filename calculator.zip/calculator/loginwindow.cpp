#include "loginwindow.h"
#include "ui_loginwindow.h"
#include "mainpage.h"
#include <QLineEdit>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    mainpage=new MainPage;  //创建主页面
    /*设置登录窗口的名称、大小、图标*/
    this->setWindowIcon(QIcon(":/images/Icon.ico"));
    this->setWindowTitle("CASIO calculator");
    this->setFixedSize(570,400);
    ui->password->setEchoMode(QLineEdit::Password);  //设置密码输入框的输入为密码模式（即无法看到输入内容）
    ui->pushButton_3->setStyleSheet("background-color: rgb(202, 202, 202)");  //设置"跳过登录"按钮为灰色
    /*设置背景图*/
    this->setAutoFillBackground(true);  //允许绘制
    QPixmap background=QPixmap(":/images/0.gif").scaled(this->size());  //创建图片控件
    QPalette palette;
    palette.setBrush(QPalette::Window,QBrush(background));  //设置调色板的窗口背景为指定图片
    this->setPalette(palette);  //将调色板应用到当前窗口
    ui->pushButton_3->setStyleSheet("QPushButton{background-color: rgb(11,23,28);color:rgb(253,254,255);}");  //设置"跳过登录"按钮的背景颜色
    /*设置"登录"和"退出"两个按钮的键盘快捷键*/
    ui->pushButton->setShortcut(QKeySequence("Enter"));
    ui->pushButton_2->setShortcut(QKeySequence("Esc"));
}

MainWindow::~MainWindow()
{
    delete ui;
}

/*定义退出按钮的槽函数*/
void MainWindow::on_pushButton_2_clicked()
{
    this->close();  //关闭当前页面，退出程序
}

/*定义登录按钮的槽函数*/
void MainWindow::on_pushButton_clicked()
{
    this->hide();  //隐藏登录页面
    QString myAccountNumber=ui->accountNumber->text();  //将账号转换成字符串类型
    QString myPassword=ui->password->text();  //将密码也转换成字符串类型
    if(myAccountNumber=="admin"&&myPassword=="123456")  //检验用户输入是否合法
    {
        mainpage->show();  //显示CASIO在线计算器页面
    }
    else
    {
        QMessageBox::information(this,"登录失败","账号或密码错误，请重新输入!",QMessageBox::Ok);  //设置登录失败的弹窗属性
        ui->accountNumber->clear();  //清除已输入的账号
        ui->password->clear();  //清除已输入的密码
        this->show();  //回到登录页面
    }
}

/*定义跳过登录按钮的槽函数*/
void MainWindow::on_pushButton_3_clicked()
{
    this->hide();  //隐藏登录页面
    mainpage->show();  //显示CASIO在线计算器页面
}

