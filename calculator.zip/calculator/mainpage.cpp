#include "mainpage.h"
#include "ui_mainpage.h"
#include "tips.h"
#include<QString>
#include<QChar>
#include<QMessageBox>
#include<QDebug>
#include<QMovie>
#include<cmath>
#include<stack>
#include<queue>
#include<vector>
#include<QIcon>
#include<QDialog>
#include<QTextEdit>
using std::stack;
using std::queue;
using std::vector;
MainPage::MainPage(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::MainPage)
{
    ui->setupUi(this);
    /*设置计算器主窗口的属性*/
    this->setWindowTitle("CASIO 在线计算器");  //设置计算器主页面窗口名称
    this->setFixedSize(340,500);  //设置固定窗口大小
    this->setWindowIcon(QIcon(":/images/Icon.jpeg")); // 设置图标
    /*设置夜间下雪的动态背景图片*/
    QMovie* movie=new QMovie(":/images/snow.gif"); //创建动态背景图片的控件
    movie->setScaledSize(this->size());  //设置固定大小的动态背景图片
    ui->label_gif->setMovie(movie);  //为标签添加动态背景图片
    movie->start();  //开启播放动态背景
    /*设置输入文本框的背景颜色、文本颜色*/
    ui->lineEdit->setStyleSheet("QLineEdit{background-color: rgb(0,7,7);color:rgb(255,254,255);font-weight: bold;}");
    /*设置计算器按钮属性*/
    ui->Num0->setFixedSize(51,51);  //设置数字0按钮固定大小
    ui->Num0->setStyleSheet("QPushButton{background-color: rgb(11,23,28);color:rgb(253,254,255);}");  //设置数字0按钮的背景颜色和文本颜色
    ui->Num0->setShortcut(QKeySequence("0"));  //允许键盘输入数字0
    ui->Num1->setFixedSize(51,51);  //设置数字1按钮固定大小
    ui->Num1->setStyleSheet("QPushButton{background-color: rgb(11,23,28);color:rgb(253,254,255);}");  //设置数字1按钮的背景颜色和文本颜色
    ui->Num1->setShortcut(QKeySequence("1"));  //允许键盘输入数字1
    ui->Num2->setFixedSize(51,51);  //设置数字2按钮固定大小
    ui->Num2->setStyleSheet("QPushButton{background-color: rgb(11,23,28);color:rgb(253,254,255);}");  //设置数字2按钮的背景颜色和文本颜色
    ui->Num2->setShortcut(QKeySequence("2"));  //允许键盘输入数字2
    ui->Num3->setFixedSize(51,51);  //设置数字3按钮固定大小
    ui->Num3->setStyleSheet("QPushButton{background-color: rgb(11,23,28);color:rgb(253,254,255);}");  //设置数字3按钮的背景颜色和文本颜色
    ui->Num3->setShortcut(QKeySequence("3"));  //允许键盘输入数字3
    ui->Num4->setFixedSize(51,51);  //设置数字4按钮固定大小
    ui->Num4->setStyleSheet("QPushButton{background-color: rgb(11,23,28);color:rgb(253,254,255);}");  //设置数字4按钮的背景颜色和文本颜色
    ui->Num4->setShortcut(QKeySequence("4"));  //允许键盘输入数字4
    ui->Num5->setFixedSize(51,51);  //设置数字5按钮固定大小
    ui->Num5->setStyleSheet("QPushButton{background-color: rgb(11,23,28);color:rgb(253,254,255);}");  //设置数字5按钮的背景颜色和文本颜色
    ui->Num5->setShortcut(QKeySequence("5"));  //允许键盘输入数字5
    ui->Num6->setFixedSize(51,51);  //设置数字6按钮固定大小
    ui->Num6->setStyleSheet("QPushButton{background-color: rgb(11,23,28);color:rgb(253,254,255);}");  //设置数字6按钮的背景颜色和文本颜色
    ui->Num6->setShortcut(QKeySequence("6"));  //允许键盘输入数字6
    ui->Num7->setFixedSize(51,51);  //设置数字7按钮固定大小
    ui->Num7->setStyleSheet("QPushButton{background-color: rgb(11,23,28);color:rgb(253,254,255);}");  //设置数字7按钮的背景颜色和文本颜色
    ui->Num7->setShortcut(QKeySequence("7"));  //允许键盘输入数字7
    ui->Num8->setFixedSize(51,51);  //设置数字8按钮固定大小
    ui->Num8->setStyleSheet("QPushButton{background-color: rgb(11,23,28);color:rgb(253,254,255);}");  //设置数字8按钮的背景颜色和文本颜色
    ui->Num8->setShortcut(QKeySequence("8"));  //允许键盘输入数字8
    ui->Num9->setFixedSize(51,51);  //设置数字9按钮固定大小
    ui->Num9->setStyleSheet("QPushButton{background-color: rgb(11,23,28);color:rgb(253,254,255);}");  //设置数字9按钮的背景颜色和文本颜色
    ui->Num9->setShortcut(QKeySequence("9"));  //允许键盘输入数字9
    ui->Dot->setFixedSize(51,51);  //设置小数点按钮固定大小
    ui->Dot->setStyleSheet("QPushButton{background-color: rgb(11,23,28);color:rgb(253,254,255);}");  //设置小数点按钮的背景颜色和文本颜色
    ui->Dot->setShortcut(QKeySequence("."));  //允许键盘输入小数点
    ui->Back->setFixedSize(51,51);  //设置退格按钮固定大小
    ui->Back->setStyleSheet("QPushButton{background-color: rgb(49,154,144);color:rgb(253,254,255);}");  //设置退格按钮的背景颜色和文本颜色
    ui->Back->setShortcut(QKeySequence("Backspace"));  //允许用键盘实现退格功能
    ui->Clear->setFixedSize(51,51);  //设置清零按钮固定大小
    ui->Clear->setStyleSheet("QPushButton{background-color: rgb(49,154,144);color:rgb(253,254,255);}");  //设置清零按钮的背景颜色和文本颜色
    ui->Clear->setShortcut(QKeySequence("Delete"));  //允许用键盘实现清零功能
    ui->ConMul->setFixedSize(51,51);  //设置阶乘按钮固定大小
    ui->ConMul->setStyleSheet("QPushButton{background-color: rgb(21,74,77);color:rgb(253,254,255);}");  //设置阶乘按钮的背景颜色和文本颜色
    ui->ConMul->setShortcut(QKeySequence("Shift+1"));  //允许用键盘实现输入阶乘符号
    ui->Div->setFixedSize(51,51);  //设置除号按钮固定大小
    ui->Div->setStyleSheet("QPushButton{background-color: rgb(251,158,143);color:rgb(253,254,255);}");  //设置除号按钮的背景颜色和文本颜色
    ui->Div->setShortcut(QKeySequence("/"));  //允许用键盘实现输入除号
    ui->Equal->setFixedSize(51,51);  //设置等号按钮固定大小
    ui->Equal->setStyleSheet("QPushButton{background-color: rgb(49,154,144);color:rgb(253,254,255);}");  //设置等号按钮的背景颜色和文本颜色
    ui->Equal->setShortcut(QKeySequence("Enter"));  //允许用键盘实现输入等号（求值）
    ui->ExtractionRoot->setFixedSize(51,51);  //设置根号按钮固定大小
    ui->ExtractionRoot->setStyleSheet("QPushButton{background-color: rgb(21,74,77);color:rgb(253,254,255);}");  //设置开根按钮的背景颜色和文本颜色
    ui->ExtractionRoot->setShortcut(QKeySequence("Space"));  //允许用键盘实现输入根号
    ui->LeftBracket->setFixedSize(51,51);  //设置左括号按钮固定大小
    ui->LeftBracket->setStyleSheet("QPushButton{background-color: rgb(21,74,77);color:rgb(253,254,255);}");  //设置左括号按钮的背景颜色和文本颜色
    ui->LeftBracket->setShortcut(QKeySequence("Shift+9"));  //允许用键盘实现输入左括号
    ui->Mul->setFixedSize(51,51);  //设置乘号按钮固定大小
    ui->Mul->setStyleSheet("QPushButton{background-color: rgb(251,158,143);color:rgb(253,254,255);}");  //设置乘号按钮的背景颜色和文本颜色
    ui->Mul->setShortcut(QKeySequence("*"));  //允许用键盘实现输入乘号
    ui->Plus->setFixedSize(51,51);  //设置加号按钮固定大小
    ui->Plus->setStyleSheet("QPushButton{background-color: rgb(251,158,143);color:rgb(253,254,255);}");  //设置加号按钮的背景颜色和文本颜色
    ui->Plus->setShortcut(QKeySequence("+"));  //允许用键盘实现输入加号
    ui->RightBracket->setFixedSize(51,51);  //设置右括号按钮固定大小
    ui->RightBracket->setStyleSheet("QPushButton{background-color: rgb(21,74,77);color:rgb(253,254,255);}");  //设置右括号按钮的背景颜色和文本颜色
    ui->RightBracket->setShortcut(QKeySequence("Shift+0"));  //允许用键盘实现输入右括号
    ui->Square->setFixedSize(51,51);  //设置平方按钮固定大小
    ui->Square->setStyleSheet("QPushButton{background-color: rgb(21,74,77);color:rgb(253,254,255);}");  //设置平方按钮的背景颜色和文本颜色
    ui->Square->setShortcut(QKeySequence("Shift+6"));  //允许用键盘实现输入二次方
    ui->Sub->setFixedSize(51,51);  //设置减号按钮固定大小
    ui->Sub->setStyleSheet("QPushButton{background-color: rgb(251,158,143);color:rgb(253,254,255);}");  //设置减号按钮的背景颜色和文本颜色
    ui->Sub->setShortcut(QKeySequence("-"));  //允许用键盘实现输入减号
    ui->Mod->setFixedSize(51,51);  //设置取余按钮固定大小
    ui->Mod->setStyleSheet("QPushButton{background-color: rgb(21,74,77);color:rgb(253,254,255);}");  //设置取余按钮的背景颜色和文本颜色
    ui->Mod->setShortcut(QKeySequence("Shift+5"));  //允许用键盘实现输入取余号
    /*设置计算器使用提示框*/
    ui->tips->setStyleSheet("QPushButton{background-color: rgb(255,255,0);color:rgb(127,0,0);font-weight: bold;}");  //设置tips按钮的背景颜色、文本颜色和字体加粗
    ui->tips->setFixedSize(70,25);  //设置tips按钮为固定大小
}

MainPage::~MainPage()
{
    delete ui;
}

/*判断当前位置输入数字是否合法的判断函数*/
bool MainPage::isInputLogicalNum()
{
    if(ui->lineEdit->text()=="")  //处理第一个输入数字的情况
    {
        return true;
    }
    QString temp=ui->lineEdit->text().back();  //获取文本框内最后一位字符
    if(temp==")"||temp=="!")  //如果是右括号或阶乘，则输入不合法
    {
        return false;
    }
    return true;
}

/*判断输入数字是否合法的处理函数*/
void MainPage::judgeInputNum()
{
    if(!isInputLogicalNum())  //判断当前位置输入数字是否合法
    {
        QMessageBox::critical(this,"CASIO 在线计算器","输入格式不正确，请修改输入!",QMessageBox::Ok);  //设置输入失败的弹窗属性
        this->show();  //回到主页面
        return;
    }
}

/*输入数字0的槽函数*/
void MainPage::on_Num0_clicked()
{
    if(ui->lineEdit->text()=="")  //处理第一个输入数字的情况
    {
        ui->lineEdit->insert("0");  //输入运算数0
        return;
    }
    QString temp=ui->lineEdit->text().back();  //获取文本框内最后一位字符
    if(temp==")"||temp=="!"||temp=="÷"||temp=="%")  //如果是右括号、阶乘除号、取余号，则输入不合法
    {
        QMessageBox::critical(this,"CASIO 在线计算器","输入格式不正确，请修改输入!",QMessageBox::Ok);  //设置输入失败的弹窗属性
        this->show();  //回到主页面
        return;
    }
    ui->lineEdit->insert("0");  //输入运算数0
}

/*输入数字1的槽函数*/
void MainPage::on_Num1_clicked()
{
    judgeInputNum();  //调用判断输入是否合法的处理函数
    ui->lineEdit->insert("1");  //输入运算数1
}

/*输入数字2的槽函数*/
void MainPage::on_Num2_clicked()
{
    judgeInputNum();  //调用判断输入是否合法的处理函数
    ui->lineEdit->insert("2");  //输入运算数2
}

/*输入数字3的槽函数*/
void MainPage::on_Num3_clicked()
{
    judgeInputNum();  //调用判断输入是否合法的处理函数
    ui->lineEdit->insert("3");  //输入运算数3
}

/*输入数字4的槽函数*/
void MainPage::on_Num4_clicked()
{
    judgeInputNum();  //调用判断输入是否合法的处理函数
    ui->lineEdit->insert("4");  //输入运算数4
}

/*输入数字5的槽函数*/
void MainPage::on_Num5_clicked()
{
    judgeInputNum();  //调用判断输入是否合法的处理函数
    ui->lineEdit->insert("5");  //输入运算数5
}

/*输入数字6的槽函数*/
void MainPage::on_Num6_clicked()
{
    judgeInputNum();  //调用判断输入是否合法的处理函数
    ui->lineEdit->insert("6");  //输入运算数6
}

/*输入数字7的槽函数*/
void MainPage::on_Num7_clicked()
{
    judgeInputNum();  //调用判断输入是否合法的处理函数
    ui->lineEdit->insert("7");  //输入运算数7
}

/*输入数字8的槽函数*/
void MainPage::on_Num8_clicked()
{
    judgeInputNum();  //调用判断输入是否合法的处理函数
    ui->lineEdit->insert("8");  //输入运算数8
}

/*输入数字9的槽函数*/
void MainPage::on_Num9_clicked()
{
    judgeInputNum();  //调用判断输入是否合法的处理函数
    ui->lineEdit->insert("9");  //输入运算数9
}

/*处理输入第一个符号是否合法的函数*/
void MainPage::tackleFirstInputOper(QString a)
{
    if(a=="("||a=="√")
    {
        ui->lineEdit->insert(a);
    }
    else
    {
        QMessageBox::critical(this,"CASIO 在线计算器","输入格式不正确，请修改输入!",QMessageBox::Ok);  //设置输入失败的弹窗属性
        this->show();  //回到主页面
    }
}

/*判断非第一个输入的符号是否合法的函数*/
bool MainPage::isInputLogicalOper(QString oper)
{
    QString temp=ui->lineEdit->text().back();  //获取文本框内最后一位字符
    if(oper=="√")
    {
        if(temp=="!"||temp==")"||temp==".")  //考虑不能直接连接根号的符号
        {
            return false;
        }
        return true;
    }
    else if(oper==".")
    {
        if(temp=="!"||temp=="("||temp==")"||temp=="√"||temp=="%"||temp=="+"||temp=="-"||temp=="×"||temp=="÷"||temp==".")  //考虑不能直接连接小数点的符号
        {
            return false;
        }
        return true;
    }
    else if(oper=="%"||oper=="+"||oper=="-"||oper=="×"||oper=="÷")
    {
        if(temp=="("||temp=="√"||temp=="%"||temp=="+"||temp=="-"||temp=="×"||temp=="÷"||temp==".")  //考虑不能直接连接加、减、乘、除、取余的符号
        {
            return false;
        }
        return true;
    }
    else if(oper=="!")
    {
        if(temp=="("||temp=="√"||temp=="%"||temp=="+"||temp=="-"||temp=="×"||temp=="÷"||temp==".")  //考虑不能直接连接阶乘的符号
        {
            return false;
        }
        return true;
    }
    else if(oper=="(")
    {
        //考虑不能直接连接左括号的符号
        if(temp=="!"||temp==")"||temp=="."||temp=="0"||temp=="1"||temp=="2"||temp=="3"||temp=="4"||temp=="5"||temp=="6"||temp=="7"||temp=="8"||temp=="9")
        {
            return false;
        }
        return true;
    }
    else if(oper==")")
    {
        if(temp=="("||temp=="%"||temp=="+"||temp=="-"||temp=="×"||temp=="÷"||temp==".")  //考虑不能直接连接右括号的符号
        {
            return false;
        }
        return true;
    }
    else
    {
        if(temp=="("||temp=="√"||temp=="%"||temp=="+"||temp=="-"||temp=="×"||temp=="÷"||temp==".")  //考虑不能直接连接平方的符号
        {
            return false;
        }
        return true;
    }
}

/*小数点的输入*/
void MainPage::on_Dot_clicked()
{
    QString aa=ui->lineEdit->text();  //获取当前文本框的输入
    if(aa=="")  //判断当前是否为第一次输入
    {
        tackleFirstInputOper(".");  //处理第一次输入的情况
        return;
    }
    if(!isInputLogicalOper("."))  //判断输入是否合法
    {
        QMessageBox::critical(this,"CASIO 在线计算器","输入格式不正确，请修改输入!",QMessageBox::Ok);  //设置输入失败的弹窗属性
        this->show();  //回到主页面
        return;
    }
    ui->lineEdit->insert(".");  //输入小数点
}

/*清零符号的输入*/
void MainPage::on_Clear_clicked()
{
    ui->lineEdit->clear();  //实现计算器清零功能
}

/*退格符号的输入*/
void MainPage::on_Back_clicked()
{
    QString contents=ui->lineEdit->text();  //获取当前文本内容
    int strlens=contents.length();  //计算文本字符串长度
    if(strlens>0)  //判断当前输入框内是否文本
    {
        contents.chop(1);  //删除最后一个字符
        ui->lineEdit->setText(contents);  //更新文本内容
    }
}

/*左括号的输入*/
void MainPage::on_LeftBracket_clicked()
{
    QString aa=ui->lineEdit->text();  //获取当前文本框的输入
    if(aa=="")  //判断当前是否为第一次输入
    {
        tackleFirstInputOper("(");  //处理第一次输入的情况
        return;
    }
    if(!isInputLogicalOper("("))  //判断输入是否合法
    {
        QMessageBox::critical(this,"CASIO 在线计算器","输入格式不正确，请修改输入!",QMessageBox::Ok);  //设置输入失败的弹窗属性
        this->show();  //回到主页面
        return;
    }
    ui->lineEdit->insert("(");  //输入左括号
}

/*右括号的输入*/
void MainPage::on_RightBracket_clicked()
{
    QString aa=ui->lineEdit->text();  //获取当前文本框的输入
    if(aa=="")  //判断当前是否为第一次输入
    {
        tackleFirstInputOper(")");  //处理第一次输入的情况
        return;
    }
    if(!isInputLogicalOper(")"))  //判断输入是否合法
    {
        QMessageBox::critical(this,"CASIO 在线计算器","输入格式不正确，请修改输入!",QMessageBox::Ok);  //设置输入失败的弹窗属性
        this->show();  //回到主页面
        return;
    }
    ui->lineEdit->insert(")");  //输入右括号
}

/*阶乘符号的输入*/
void MainPage::on_ConMul_clicked()
{
    QString aa=ui->lineEdit->text();  //获取当前文本框的输入
    if(aa=="")  //判断当前是否为第一次输入
    {
        tackleFirstInputOper("!");  //处理第一次输入的情况
        return;
    }
    if(!isInputLogicalOper("!"))  //判断输入是否合法
    {
        QMessageBox::critical(this,"CASIO 在线计算器","输入格式不正确，请修改输入!",QMessageBox::Ok);  //设置输入失败的弹窗属性
        this->show();  //回到主页面
        return;
    }
    ui->lineEdit->insert("!");  //输入阶乘符号
}

/*加号的输入*/
void MainPage::on_Plus_clicked()
{
    QString aa=ui->lineEdit->text();  //获取当前文本框的输入
    if(aa=="")  //判断当前是否为第一次输入
    {
        tackleFirstInputOper("+");  //处理第一次输入的情况
        return;
    }
    if(!isInputLogicalOper("+"))  //判断输入是否合法
    {
        QMessageBox::critical(this,"CASIO 在线计算器","输入格式不正确，请修改输入!",QMessageBox::Ok);  //设置输入失败的弹窗属性
        this->show();  //回到主页面
        return;
    }
    ui->lineEdit->insert("+");  //输入加号
}

/*减号的输入*/
void MainPage::on_Sub_clicked()
{
    QString aa=ui->lineEdit->text();  //获取当前文本框的输入
    if(aa=="")  //判断当前是否为第一次输入
    {
        tackleFirstInputOper("-");  //处理第一次输入的情况
        return;
    }
    if(!isInputLogicalOper("-"))  //判断输入是否合法
    {
        QMessageBox::critical(this,"CASIO 在线计算器","输入格式不正确，请修改输入!",QMessageBox::Ok);  //设置输入失败的弹窗属性
        this->show();  //回到主页面
        return;
    }
    ui->lineEdit->insert("-");  //输入减号
}

/*乘号的输入*/
void MainPage::on_Mul_clicked()
{
    QString aa=ui->lineEdit->text();  //获取当前文本框的输入
    if(aa=="")  //判断当前是否为第一次输入
    {
        tackleFirstInputOper("×");  //处理第一次输入的情况
        return;
    }
    if(!isInputLogicalOper("×"))  //判断输入是否合法
    {
        QMessageBox::critical(this,"CASIO 在线计算器","输入格式不正确，请修改输入!",QMessageBox::Ok);  //设置输入失败的弹窗属性
        this->show();  //回到主页面
        return;
    }
    ui->lineEdit->insert("×");  //输入乘号
}

/*除号的输入*/
void MainPage::on_Div_clicked()
{
    QString aa=ui->lineEdit->text();  //获取当前文本框的输入
    if(aa=="")  //判断当前是否为第一次输入
    {
        tackleFirstInputOper("÷");  //处理第一次输入的情况
        return;
    }
    if(!isInputLogicalOper("÷"))  //判断输入是否合法
    {
        QMessageBox::critical(this,"CASIO 在线计算器","输入格式不正确，请修改输入!",QMessageBox::Ok);  //设置输入失败的弹窗属性
        this->show();  //回到主页面
        return;
    }
    ui->lineEdit->insert("÷");  //输入除号
}

/*取余符号的输入*/
void MainPage::on_Mod_clicked()
{
    QString aa=ui->lineEdit->text();  //获取当前文本框的输入
    if(aa=="")  //判断当前是否为第一次输入
    {
        tackleFirstInputOper("%");  //处理第一次输入的情况
        return;
    }
    if(!isInputLogicalOper("%"))  //判断输入是否合法
    {
        QMessageBox::critical(this,"CASIO 在线计算器","输入格式不正确，请修改输入!",QMessageBox::Ok);  //设置输入失败的弹窗属性
        this->show();  //回到主页面
        return;
    }
    ui->lineEdit->insert("%");  //输入取余符号
}

/*根号符号的输入*/
void MainPage::on_ExtractionRoot_clicked()
{
    QString aa=ui->lineEdit->text();  //获取当前文本框的输入
    if(aa=="")  //判断当前是否为第一次输入
    {
        tackleFirstInputOper("√");  //处理第一次输入的情况
        return;
    }
    if(!isInputLogicalOper("√"))  //判断输入是否合法
    {
        QMessageBox::critical(this,"CASIO 在线计算器","输入格式不正确，请修改输入!",QMessageBox::Ok);  //设置输入失败的弹窗属性
        this->show();  //回到主页面
        return;
    }
    ui->lineEdit->insert("√");  //输入根号
}

/*判断是否为数字的函数*/
bool isDigit(QString a)
{
    bool success;
    double temp=a.toDouble(&success);
    if(!success)
    {
        return false;
    }
    return true;
}

/*判断运算符的优先级*/
int showPriorityLevel(QString str)
{
    if(str=="+"||str=="-")
    {
        return 1;
    }
    else if(str=="×"||str=="÷"||str=="%")
    {
        return 2;
    }
    return 0;
}

/*平方符号的输入*/
void MainPage::on_Square_clicked()
{
    QString contents=ui->lineEdit->text();  //获取当前文本内容
    if(contents=="")  //处理当前输入框为空的情况
    {
        QMessageBox::critical(this,"CASIO 在线计算器","输入格式不正确，请修改输入!",QMessageBox::Ok);  //设置输入失败的弹窗属性
        this->show();  //回到主页面
        return;
    }
    QString lastChar=contents.back();  //查看文本内容的最后一个字符
    if(lastChar==")")
    {
        int strlens=contents.length();  //计算文本字符串长度
        QString res="";  //定义空字符串
        for(int i=0;i<strlens;i++)
        {
            if(contents[i]=='(')  //判断文本中是否有左括号
            {
                res=contents.mid(i,strlens-i);  //截取括号内的文本内容
                ui->lineEdit->insert("×");  //在输入框中添加乘号
                ui->lineEdit->insert(res);  //在输入框中添加截取到的文本内容，实现平方运算的格式输入
                return;
            }
        }
        QMessageBox::critical(this,"CASIO 在线计算器","输入缺少左括号，请修改输入!",QMessageBox::Ok);  //设置输入失败的弹窗属性
        this->show();  //回到主页面
        return;
    }
    else if(lastChar=="!")
    {
        contents.chop(1);  //删除最后一个字符
        QString temp= contents.back();  //获取新字符串的最后一个字符
        double tempnum=temp.toDouble();  //将该字符转换成数字类型
        if(tempnum==0&&contents.back()!=')'&&temp!="0")  //处理最后一个字符为非右括号的运算符的情况
        {
            QMessageBox::critical(this,"CASIO 在线计算器","运算符后缺少操作数，请修改输入!",QMessageBox::Ok);  //设置输入失败的弹窗属性
            this->show();  //回到主页面
        }
        else if(contents.back()==')')  //处理最后一个字符为右括号的情况
        {
            int contentsLen=contents.length();  //计算文本字符串长度
            for(int i=contentsLen-1;;i--)  //从后往前遍历字符串，找到左括号的位置
            {
                if(i==-1)  //处理无左括号的错误情况
                {
                    QMessageBox::critical(this,"CASIO 在线计算器","输入缺少左括号，请修改输入!",QMessageBox::Ok);  //设置输入失败的弹窗属性
                    this->show();  //回到主页面
                    return;
                }
                if(contents[i]=='(')
                {
                    QString a=contents.mid(i,contentsLen-i);  //截取括号内的文本内容
                    ui->lineEdit->insert("×");  //在输入框中添加乘号
                    ui->lineEdit->insert(a);  //在输入框中添加截取到的文本内容，实现平方运算的格式输入
                    ui->lineEdit->insert("!");  //在输入框中添加阶乘符号
                    return;
                }
            }
        }
        else
        {
            int contentsLen=contents.length();  //计算文本字符串长度
            for(int i=contentsLen-1;;i--)  //从后往前遍历字符串，找到左括号的位置
            {
                if(i==-1)  //处理当前文本全部为数字的情况
                {
                    ui->lineEdit->insert("×");  //在输入框中添加乘号
                    ui->lineEdit->insert(contents);  //在输入框中添加截取到的文本内容，实现平方运算的格式输入
                    ui->lineEdit->insert("!");  //在输入框中添加阶乘符号
                    return;
                }
                if(contents[i]=='.')  //阶乘的操作数必须为整数
                {
                    QMessageBox::critical(this,"CASIO 在线计算器","阶乘只适用于整数，请修改输入!",QMessageBox::Ok);  //设置输入失败的弹窗属性
                    this->show();  //回到主页面
                    return;
                }
                QString a=contents[i];
                int a_num=a.toInt();  //将字符串转换成数字型
                if(a_num==0&&contents[i]!='0')  //从后往前查找第一个非数字的字符
                {
                    QString b=contents.mid(i+1,contentsLen-i);  //截取括号内的文本内容
                    ui->lineEdit->insert("×");  //在输入框中添加乘号
                    ui->lineEdit->insert(b);  //在输入框中添加截取到的文本内容，实现平方运算的格式输入
                    ui->lineEdit->insert("!");  //在输入框中添加阶乘符号
                    return;
                }
            }
        }
        return;
    }
    double strnum=lastChar.toDouble();  //将字符转换成数字类型
    if(strnum==0&&lastChar!="0")  //处理最后一个字符为其他运算符的情况
    {
        QMessageBox::critical(this,"CASIO 在线计算器","运算符后缺少操作数，请修改输入!",QMessageBox::Ok);  //设置输入失败的弹窗属性
        this->show();  //回到主页面
        return;
    }
    int clen=contents.length();  //计算文本字符串长度
    for(int i=clen-1;;i--)  //从后向前查找第一个非数字、非小数点的运算符的位置
    {
        if(i==-1)
        {
            ui->lineEdit->insert("×");  //在输入框中添加乘号
            ui->lineEdit->insert(contents);  //在输入框中添加截取到的文本内容，实现平方运算的格式输入
            return;
        }
        QString c=contents[i];
        double c_dou=c.toDouble();  //将字符转换成double类型
        if(c_dou==0&&c!='0'&&c!='.'&&c!="√")  //判断当前字符是否为第一个非数字、非小数点的运算符
        {
            QString d=contents.mid(i+1,clen-i);  //截取括号内的文本内容
            ui->lineEdit->insert("×");  //在输入框中添加乘号
            ui->lineEdit->insert(d);  //在输入框中添加截取到的文本内容，实现平方运算的格式输入
            return;
        }
    }
}

/*计算含有+、-、*、/、%的表达式的函数*/
double MainPage::calculate(QString* str,bool &p)
{
    queue<QString> q;  //存放中缀表达式的队列
    queue<QString> postfix_notation;  //存放后缀表达式的队列
    stack<QString> op;  //此栈用于 中缀表达式变成后缀表达式 以及 计算后缀表达式
    int strLen=str->length();  //获取原字符串的长度
    vector<int> oper;  //存放原字符串中所有运算符下标的向量
    for(int i=0;i<strLen;i++)  //循环遍历，记录每个运算符的下标
    {
        QString a=(*str)[i];
        double b=a.toDouble();  //实现QChar->QString->double类型转换
        if((*str)[i]=='.')  //忽略小数点
        {
            continue;
        }
        if((*str)[i]!='0'&&b==0)
        {
            oper.push_back(i);  //将非小数点的运算符的下标存到向量oper中
        }
    }
    if(oper.empty())  //如果表达式中没有运算符
    {
        double final_ans=str->toDouble();  //讲字符串转换为数字
        return final_ans;
    }
    if(oper[0]==0)
    {
        for(int j=0;j<oper.size();j++)  //利用运算符的下标，按照运算逻辑分割原字符串，并将每一部分存入队列q中
        {
            q.push((*str)[oper[j]]);  //将运算符入队列
            QString substr=str->mid(oper[j]+1,oper[j+1]-oper[j]-1);  //截取操作数
            if(substr=="")
            {
                continue;
            }
            q.push(substr);  //按照从前往后的顺序依次存储
        }
    }
    else
    {
        int k=oper[0];
        QString substr=str->mid(0,k);  //截取第一个操作数
        q.push(substr);  //将第一个操作数入队列
        for(int j=0;j<oper.size();j++)  //循环遍历后面的每一个运算符和操作数，做相同操作
        {
            q.push((*str)[oper[j]]);  //将运算符入队列
            QString a=str->mid(oper[j]+1,oper[j+1]-oper[j]-1);  //截取操作数
            if(a=="")
            {
                continue;
            }
            q.push(a);  //按照从前往后的顺序依次存储
        }
    }
    while(!q.empty())  //判断队列是否为空
    {
        QString temp=q.front();  //按顺序取出一个字符
        q.pop();
        if(isDigit(temp))  //判断是否为数字
        {
            postfix_notation.push(temp);   //数字直接入队
            continue;
        }
        else if(temp=="(")
        {
            op.push(temp);  //左括号入栈
        }
        else if(temp==")")
        {
            if(op.empty())  //如果栈为空且最后一个元素为右括号，则输入不合法
            {
                QMessageBox::critical(this,"CASIO 在线计算器","括号不匹配，请修改输入!",QMessageBox::Ok);  //设置输入失败的弹窗属性
                p=false;  //修改监测变量的真值
                return -1;
            }
            else
            {
                QString midvar;
                while(!op.empty())  //判断栈是否为空
                {
                    midvar=op.top();  //取栈顶元素
                    op.pop();
                    if(midvar=="(")  //如果取到左括号，则停止
                    {
                        break;
                    }
                    if(midvar==")")  //跳过右括号
                    {
                        continue;
                    }
                    postfix_notation.push(midvar);  //将其他元素放入队列
                }
                if(midvar!="(")  //如果最后一个元素不为左括号，则输入不合法
                {
                    QMessageBox::critical(this,"CASIO 在线计算器","括号不匹配，请修改输入!",QMessageBox::Ok);  //设置输入失败的弹窗属性
                    p=false;  //修改监测变量的真值
                    return -1;
                }
            }
        }
        else  //处理当前字符为+、-、×、/、%这些基本运算符的情况
        {
            while(!op.empty()&&op.top()!="("&&showPriorityLevel(op.top())>=showPriorityLevel(temp))  //按照运算符之间的优先级决定入栈、入队列顺序
            {
                QString a=op.top();  //取栈顶元素
                op.pop();
                postfix_notation.push(a);  //入队列
            }
            op.push(temp);  //入栈
        }
    }
    while(!op.empty())  //将栈中剩余所有元素依次入队列
    {
        QString b=op.top();  //取出栈顶元素
        if(b=="("||b==")")  //处理括号不匹配的情况
        {
            QMessageBox::critical(this,"CASIO 在线计算器","括号不匹配，请修改输入!",QMessageBox::Ok);  //设置输入失败的弹窗属性
            p=false;  //修改监测变量的真值
            return -1;
        }
        op.pop();
        postfix_notation.push(b);  //入队
    }
    stack<double> calculation;  //创建用于后缀表达式求值的栈
    while(!postfix_notation.empty())  //循环遍历队列，直至其空为止
    {
        QString tran=postfix_notation.front();  //取队首元素
        postfix_notation.pop();
        double trans=tran.toDouble();
        if(trans==0&&tran!="0")  //如果队首元素是运算符
        {
            double y=calculation.top();  //从栈中取出一个操作数
            calculation.pop();
            double x=calculation.top();  //从栈中再取出一个操作数
            calculation.pop();
            if(tran=="+")
            {
                calculation.push(x+y);  //将运算后的结果重新放入栈中
            }
            else if(tran=="-")
            {
                calculation.push(x-y);  //将运算后的结果重新放入栈中
            }
            else if(tran=="×")
            {
                calculation.push(x*y);  //将运算后的结果重新放入栈中
            }
            else if(tran=="÷")
            {
                if(y==0)  //判断除数是否为0
                {
                    QMessageBox::critical(this,"CASIO 在线计算器","除数不能为0，请修改输入!",QMessageBox::Ok);  //设置输入失败的弹窗属性
                    p=false;  //修改监测变量的真值
                    return -1;
                }
                calculation.push(x/y);  //将运算后的结果重新放入栈中
            }
            else if(tran=="%")
            {
                int y_=int(y);
                if(y==0)  //判断取余的操作数是否为0
                {
                    QMessageBox::critical(this,"CASIO 在线计算器","不能对0取余，请修改输入!",QMessageBox::Ok);  //设置输入失败的弹窗属性
                    p=false;  //修改监测变量的真值
                    return -1;
                }
                if(y_!=y)  //判断操作数是否为整数
                {
                    QMessageBox::critical(this,"CASIO 在线计算器","取余运算只能对整数进行，请修改输入!",QMessageBox::Ok);  //设置输入失败的弹窗属性
                    p=false;  //修改监测变量的真值
                    return -1;
                }
                int x_=int(x);
                if(x_!=x)  //判断操作数是否为整数
                {
                    QMessageBox::critical(this,"CASIO 在线计算器","取余运算只能对整数进行，请修改输入!",QMessageBox::Ok);  //设置输入失败的弹窗属性
                    p=false;  //修改监测变量的真值
                    return -1;
                }
                calculation.push(x_%y_);  //将运算后的结果重新放入栈中
            }
        }
        else
        {
            calculation.push(trans);  //将操作数直接放入栈中
        }
    }
    double final_ans=calculation.top();  //取出最终运算结果并返回
    return final_ans;
}

/*计算阶乘数值的函数*/
int MainPage::calculateConMul(int n,bool& p)
{
    int res=1;  //定义保存返回结果的变量
    if(n<0)
    {
        QMessageBox::critical(this,"CASIO 在线计算器","阶乘的操作数不能为负，请修改输入!",QMessageBox::Ok);  //设置输入失败的弹窗属性
        this->show();  //回到主页面
        p=false;  //修改监测变量的真值
        return -1;
    }
    for(int i=n;i>=1;i--)  //用循环计算阶乘
    {
        res*=i;
    }
    return res;
}

/*处理表达式中阶乘部分的函数*/
void MainPage::tackleConMul(QString* expression,bool &p)
{
    int expressionLen=expression->length();  //更新表达式长度的值
    for(int i=expressionLen-1;i>=0;i--)  //处理表达式中的阶乘部分的计算
    {
        if((*expression)[i]=='!'&&(*expression)[i-1]==')')  //处理阶乘符号前面有括号的情况
        {
            for(int j=i-1;;j--)  //循环遍历寻找左括号的位置
            {
                if(j==-1)  //处理无左括号的情况
                {
                    QMessageBox::critical(this,"CASIO 在线计算器","输入缺少左括号，请修改输入!",QMessageBox::Ok);  //设置输入失败的弹窗属性
                    this->show();  //回到主页面
                    p=false;  //修改监测变量的真值
                    return;
                }
                if((*expression)[j]=='(')  //判断当前位置是否为左括号
                {
                    QString substr2=expression->mid(j+1,i-j-2);  //截取原表达式中阶乘符号前括号内的部分
                    if(substr2.contains("√"))  //判断子串是否含有根号
                    {
                        tackleSqrt(&substr2,p);  //处理子串中带有根号的表达式部分
                        expression->replace(expression->mid(j+1,i-j-2),substr2);  //用计算后的结果替换原字符串
                    }
                    double res=calculate(&substr2,p);  //计算出此部分的结果
                    int temp=res;
                    if(temp!=res)  //判断此部分运算结果是否为整数
                    {
                        QMessageBox::critical(this,"CASIO 在线计算器","阶乘只适用于整数，请修改输入!",QMessageBox::Ok);  //设置输入失败的弹窗属性
                        this->show();  //回到主页面
                        p=false;  //修改监测变量的真值
                        return;
                    }
                    int midRes=calculateConMul(temp,p);  //计算出阶乘部分的结果
                    if(midRes==-1)  //处理输入非法的情况
                    {
                        return;
                    }
                    QString add = QString::number(midRes);  //将整数型转换成字符串类型
                    expression->remove(j,i-j+1);  //删除表达式中已经计算出来的部分
                    expression->insert(j,add);  //插入第一步计算结果
                    return;
                }
            }
        }
        else if((*expression)[i]=='!'&&(*expression)[i-1]!=')')  //处理阶乘符号前一位不是括号的情况
        {
            int j;
            for(j=i-1;j>=0;j--)  //循环遍历，找到距离阶乘符号最近的运算符
            {
                QString e=(*expression)[j];  //截取当前位置的元素
                int f=e.toInt();  //将其转换成整数类型
                if((*expression)[j]!='0'&&f==0)  //判断当前元素是否为运算符
                {
                    QString substr=expression->mid(j+1,i-j-1);  //截取原表达式中阶乘符号前括号内的部分
                    double res=calculate(&substr,p);  //计算出此部分的结果
                    int temp=res;
                    if(temp!=res)  //判断此部分运算结果是否为整数
                    {
                        QMessageBox::critical(this,"CASIO 在线计算器","阶乘只适用于整数，请修改输入!",QMessageBox::Ok);  //设置输入失败的弹窗属性
                        this->show();  //回到主页面
                        p=false;  //修改监测变量的真值
                        return;
                    }
                    int midRes=calculateConMul(temp,p);  //计算出阶乘部分的结果
                    if(midRes==-1)  //处理输入非法的情况
                    {
                        return;
                    }
                    QString add = QString::number(midRes);  //将整数型转换成字符串类型
                    expression->remove(j+1,i-j);  //删除表达式中已经计算出来的部分
                    expression->insert(j+1,add);  //插入第一步计算结果
                    break;
                }
            }
            if(j==-1)  //阶乘符号前全部是操作数
            {
                QString substr=expression->mid(j+1,i-j-1);  //截取原表达式中阶乘符号前括号内的部分
                int number=substr.toInt();
                int res=calculateConMul(number,p);
                if(res==-1)  //处理输入非法的情况
                {
                    return;
                }
                QString add = QString::number(res);  //将整数型转换成字符串类型
                expression->remove(0,i+1);  //删除表达式中已经计算出来的部分
                expression->insert(0,add);  //插入第一步计算结果
                break;
            }
        }
    }
}

/*处理表达式中根号部分的函数*/
void MainPage::tackleSqrt(QString* expression,bool &p)
{
    int expressionLen=expression->length();  //计算表达式所对应的字符串长度
    if(*expression=="")  //处理输入表达式为空的情况
    {
        return;
    }
    while(expression->contains("√"))  //一次性处理表达式中所有根式的运算
    {
        int index=expression->indexOf("√");
        if((*expression)[index+1]=='(')  //处理根号后面紧跟着左括号的情况
        {
            for(int i=index+2;;i++)  //循环变量寻找右括号的位置
            {
                if(i>=expressionLen)  //处理缺少右括号的情况
                {
                    QMessageBox::critical(this,"CASIO 在线计算器","输入缺少右括号，请修改输入!",QMessageBox::Ok);  //设置输入失败的弹窗属性
                    this->show();  //回到主页面
                    p=false;  //修改监测变量的真值
                    return;
                }
                if((*expression)[i]==')')  //判断当前位置是否为右括号
                {
                    QString* substr=new QString;
                    *substr=expression->mid(index+2,i-index-2);  //截取原表达式中括号内的部分
                    if(substr->contains("!"))  //子串包含阶乘号
                    {
                        tackleConMul(substr,p);  //调用处理阶乘的函数
                        expression->replace(expression->mid(index+2,i-index-2),*substr);  //用计算后的结果替换原字符串
                    }
                    double res=calculate(substr,p);  //计算出此部分的结果
                    if(res<0)  //处理根号下数小于0的非法情况
                    {
                        QMessageBox::critical(this,"CASIO 在线计算器","根号下数值不能为负数，请修改输入!",QMessageBox::Ok);  //设置输入失败的弹窗属性
                        this->show();  //回到主页面
                        p=false;  //修改监测变量的真值
                        return;
                    }
                    res=sqrt(res);  //进行开根运算
                    QString add = QString::number(res);  //将double型转换成字符串类型
                    expression->remove(index,i-index+1);  //删除表达式中根号下已经计算出来的部分
                    expression->insert(index,add);  //插入中间计算结果
                    break;
                }
            }
        }
        else
        {
            for(int i=index+1;;i++)  //处理根号后非左括号的情况
            {
                if(i>=expressionLen)  //根号后面无运算符
                {
                    QString sqrtStr=expression->mid(index+1,expressionLen-index-1);  //截取根号下的操作数
                    double sqrtRes=sqrt(sqrtStr.toDouble());
                    sqrtStr=QString::number(sqrtRes);  //将根号部分的运算结果存储在字符串中
                    expression->truncate(index);  //删除原先带根号的部分
                    expression->append(sqrtStr);  //添加运算完根号的字符串
                    break;
                }
                QString a=(*expression)[i];  //获取当前位置字符
                if(a.toDouble()==0&&a!='0')  //判断是否为运算符
                {
                    QString sqrtStr=expression->mid(index+1,i-index-1);  //截取根号下的操作数
                    double sqrtRes=sqrt(sqrtStr.toDouble());
                    sqrtStr=QString::number(sqrtRes);  //将根号部分的运算结果存储在字符串中
                    expression->replace(index,i-index,sqrtStr);  //替换原先带根号的部分
                    break;
                }
            }
        }
    }
}

/*实现计算表达式的功能*/
void MainPage::on_Equal_clicked()
{
    bool p=true;  //定义监测运算是否异常的变量
    QString* expression=new QString;  //创建用于存储表达式的字符串
    *expression=ui->lineEdit->text();  //获取完整表达式
    tackleSqrt(expression,p);  //调用函数，处理带有根号的部分
    if(p==false)  //结束异常情况下的程序进程
    {
        return;
    }
    tackleConMul(expression,p);  //调用函数，处理带有阶乘符号的部分
    if(p==false)  //结束异常情况下的程序进程
    {
        return;
    }
    double final_res=calculate(expression,p);  //调用基本计算函数，求出最终结果
    if(final_res==-1&&p==false)  //结束异常情况下的程序进程
    {
        return;
    }
    QString final_add = QString::number(final_res);  //将最终运算结果转换成字符串类型
    ui->lineEdit->setText(final_add);  //在输入文本框内显示最终运算结果
    delete expression;  //及时释放堆上的存储空间
}

/*定义tips按钮的槽函数*/
void MainPage::on_tips_clicked()
{
    Tips* tips=new Tips(this);  //创建tips窗口
    tips->show();  //显示tips窗口
}

