#ifndef MAINPAGE_H
#define MAINPAGE_H

#include <QWidget>

namespace Ui {
class MainPage;
}

class MainPage : public QWidget
{
    Q_OBJECT

public:
    explicit MainPage(QWidget *parent = nullptr);
    ~MainPage();
    double calculate(QString* str,bool &q);  /*计算含有+、-、*、/、%的表达式的函数*/
    int calculateConMul(int n,bool& p);  /*计算阶乘数值的函数*/
    bool isInputLogicalNum();  /*判断当前位置输入数字是否合法的判断函数*/
    void judgeInputNum();  /*判断输入数字是否合法的处理函数*/
    bool isInputLogicalOper(QString oper);  /*判断非第一个输入的符号是否合法的函数*/
    void tackleFirstInputOper(QString a);  /*处理输入第一个符号是否合法的函数*/
    void tackleConMul(QString* expression,bool &p);  /*处理表达式中阶乘部分的函数*/
    void tackleSqrt(QString* expression,bool &p);  /*处理表达式中根号部分的函数*/

private slots:
    void on_Num0_clicked();  /*输入数字0的槽函数*/

    void on_Num1_clicked();  /*输入数字1的槽函数*/

    void on_Num2_clicked();  /*输入数字2的槽函数*/

    void on_Num3_clicked();  /*输入数字3的槽函数*/

    void on_Num4_clicked();  /*输入数字4的槽函数*/

    void on_Num5_clicked();  /*输入数字5的槽函数*/

    void on_Num6_clicked();  /*输入数字6的槽函数*/

    void on_Num7_clicked();  /*输入数字7的槽函数*/

    void on_Num8_clicked();  /*输入数字8的槽函数*/

    void on_Num9_clicked();  /*输入数字9的槽函数*/

    void on_Dot_clicked();  /*小数点的输入*/

    void on_Clear_clicked();  /*清零符号的输入*/

    void on_Back_clicked();  /*退格符号的输入*/

    void on_LeftBracket_clicked();  /*左括号的输入*/

    void on_RightBracket_clicked();  /*右括号的输入*/

    void on_ConMul_clicked();  /*阶乘符号的输入*/

    void on_Plus_clicked();  /*加号的输入*/

    void on_Sub_clicked();  /*减号的输入*/

    void on_Mul_clicked();  /*乘号的输入*/

    void on_Div_clicked();  /*除号的输入*/

    void on_Mod_clicked();  /*取余符号的输入*/

    void on_Equal_clicked();  /*实现计算表达式的功能*/

    void on_Square_clicked();  /*平方符号的输入*/

    void on_ExtractionRoot_clicked();  /*根号符号的输入*/

    void on_tips_clicked();  /*定义tips按钮的槽函数*/

private:
    Ui::MainPage *ui;
};

#endif // MAINPAGE_H
