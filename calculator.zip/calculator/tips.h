#ifndef TIPS_H
#define TIPS_H

#include <QMainWindow>

namespace Ui {
class Tips;
}

class Tips : public QMainWindow
{
    Q_OBJECT

public:
    explicit Tips(QWidget *parent = nullptr);
    ~Tips();

public slots:
    void on_welfare_clicked();  /*定义转换到程序员计算器的槽函数*/

private:
    Ui::Tips *ui;
};

#endif // TIPS_H
