#ifndef PGCALCULATOR_H
#define PGCALCULATOR_H

#include <QMainWindow>

namespace Ui {
class PgCalculator;
}

class PgCalculator : public QMainWindow
{
    Q_OBJECT

public:
    explicit PgCalculator(QWidget *parent = nullptr);
    ~PgCalculator();
    bool isInputLogical();  /*判断当前输入是否合法*/
    QString numConversion(long long x,int n);  /*数值转换函数*/
    void AND(QString a,QString b,int len);  /*实现相与运算的函数*/
    void OR(QString a,QString b,int len);  /*实现相或运算的函数*/
    void shiftBitByBit(QString ori,int n,bool dir);  /*实现左移、右移的函数*/

private slots:
    void on_Num0_clicked();  /*输入数字0的槽函数*/

    void on_Num1_clicked();  /*输入数字1的槽函数*/

    void on_Num2_clicked();  /*输入数字2的槽函数*/

    void on_Num3_clicked();  /*输入数字3的槽函数*/

    void on_Num4_clicked();  /*输入数字4的槽函数*/

    void on_Num5_clicked();  /*输入数字5的槽函数*/

    void on_Num6_clicked();  /*输入数字6的槽函数*/

    void on_Num7_clicked();  /*输入数字7的槽函数*/

    void on_Num8_clicked();  /*输入数字8的槽函数*/

    void on_Num9_clicked();  /*输入数字9的槽函数*/

    void on_Clear_clicked();  /*清零符号的输入*/

    void on_Back_clicked();  /*退格符号的输入*/

    void on_Equal_clicked();  /*等号取值的槽函数*/

    void on_AND_clicked();  /*输入AND的槽函数*/

    void on_OR_clicked();  /*输入OR的槽函数*/

    void on_NOT_clicked();  /*输入NOT的槽函数*/

    void on_ShiftRight_clicked();  /*输入>>的槽函数*/

    void on_ShiftLeft_clicked();  /*输入<<的槽函数*/

private:
    Ui::PgCalculator *ui;
};

#endif // PGCALCULATOR_H
