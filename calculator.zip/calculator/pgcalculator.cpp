#include "pgcalculator.h"
#include "ui_pgcalculator.h"
#include <QMessageBox>
#include <stack>
#include <cmath>
using std::stack;

PgCalculator::PgCalculator(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::PgCalculator)
{
    ui->setupUi(this);
    /*设置PgCalculator窗口的属性*/
    this->setFixedSize(340,500);  //设置PgCalculator窗口为固定大小
    this->setWindowTitle("Programmer's Calculator");  //设置窗口标题
    this->setWindowIcon(QIcon(":/images/Icon.jpeg"));  //更换窗口图标
    /*设置背景图*/
    this->setAutoFillBackground(true);  //允许绘制
    QPixmap background=QPixmap(":/images/pic.png").scaled(this->size());  //创建图片控件
    QPalette palette;
    palette.setBrush(QPalette::Window,QBrush(background));  //设置调色板的窗口背景为指定图片
    this->setPalette(palette);  //将调色板应用到当前窗口
    this->show();  //显示PgCalculator窗口
    /*设置程序员计算器的属性*/
    /*设置显示十、二、八、十六进制的文本框的背景颜色、文本颜色*/
    ui->lineEdit_10->setStyleSheet("QLineEdit{background-color: rgb(255,254,255);color:rgb(0,7,7);}");
    ui->lineEdit_2->setStyleSheet("QLineEdit{background-color: rgb(255,254,255);color:rgb(0,7,7);}");
    ui->lineEdit_8->setStyleSheet("QLineEdit{background-color: rgb(255,254,255);color:rgb(0,7,7);}");
    ui->lineEdit_16->setStyleSheet("QLineEdit{background-color: rgb(255,254,255);color:rgb(0,7,7);}");
    /*设置计算器按钮属性*/
    ui->Num0->setFixedSize(102,51);  //设置数字0按钮固定大小
    ui->Num0->setStyleSheet("QPushButton{background-color: rgb(253,254,255);color:rgb(11,23,28);}");  //设置数字0按钮的背景颜色和文本颜色
    ui->Num0->setShortcut(QKeySequence("0"));  //允许键盘输入数字0
    ui->Num1->setFixedSize(51,51);  //设置数字1按钮固定大小
    ui->Num1->setStyleSheet("QPushButton{background-color: rgb(253,254,255);color:rgb(11,23,28);}");  //设置数字1按钮的背景颜色和文本颜色
    ui->Num1->setShortcut(QKeySequence("1"));  //允许键盘输入数字1
    ui->Num2->setFixedSize(51,51);  //设置数字2按钮固定大小
    ui->Num2->setStyleSheet("QPushButton{background-color: rgb(253,254,255);color:rgb(11,23,28);}");  //设置数字2按钮的背景颜色和文本颜色
    ui->Num2->setShortcut(QKeySequence("2"));  //允许键盘输入数字2
    ui->Num3->setFixedSize(51,51);  //设置数字3按钮固定大小
    ui->Num3->setStyleSheet("QPushButton{background-color: rgb(253,254,255);color:rgb(11,23,28);}");  //设置数字3按钮的背景颜色和文本颜色
    ui->Num3->setShortcut(QKeySequence("3"));  //允许键盘输入数字3
    ui->Num4->setFixedSize(51,51);  //设置数字4按钮固定大小
    ui->Num4->setStyleSheet("QPushButton{background-color: rgb(253,254,255);color:rgb(11,23,28);}");  //设置数字4按钮的背景颜色和文本颜色
    ui->Num4->setShortcut(QKeySequence("4"));  //允许键盘输入数字4
    ui->Num5->setFixedSize(51,51);  //设置数字5按钮固定大小
    ui->Num5->setStyleSheet("QPushButton{background-color: rgb(253,254,255);color:rgb(11,23,28);}");  //设置数字5按钮的背景颜色和文本颜色
    ui->Num5->setShortcut(QKeySequence("5"));  //允许键盘输入数字5
    ui->Num6->setFixedSize(51,51);  //设置数字6按钮固定大小
    ui->Num6->setStyleSheet("QPushButton{background-color: rgb(253,254,255);color:rgb(11,23,28);}");  //设置数字6按钮的背景颜色和文本颜色
    ui->Num6->setShortcut(QKeySequence("6"));  //允许键盘输入数字6
    ui->Num7->setFixedSize(51,51);  //设置数字7按钮固定大小
    ui->Num7->setStyleSheet("QPushButton{background-color: rgb(253,254,255);color:rgb(11,23,28);}");  //设置数字7按钮的背景颜色和文本颜色
    ui->Num7->setShortcut(QKeySequence("7"));  //允许键盘输入数字7
    ui->Num8->setFixedSize(51,51);  //设置数字8按钮固定大小
    ui->Num8->setStyleSheet("QPushButton{background-color: rgb(253,254,255);color:rgb(11,23,28);}");  //设置数字8按钮的背景颜色和文本颜色
    ui->Num8->setShortcut(QKeySequence("8"));  //允许键盘输入数字8
    ui->Num9->setFixedSize(51,51);  //设置数字9按钮固定大小
    ui->Num9->setStyleSheet("QPushButton{background-color: rgb(253,254,255);color:rgb(11,23,28);}");  //设置数字9按钮的背景颜色和文本颜色
    ui->Num9->setShortcut(QKeySequence("9"));  //允许键盘输入数字9
    ui->Back->setFixedSize(51,51);  //设置退格按钮固定大小
    ui->Back->setStyleSheet("QPushButton{background-color: rgb(49,154,144);color:rgb(253,254,255);}");  //设置退格按钮的背景颜色和文本颜色
    ui->Back->setShortcut(QKeySequence("Backspace"));  //允许用键盘实现退格功能
    ui->Clear->setFixedSize(51,51);  //设置清零按钮固定大小
    ui->Clear->setStyleSheet("QPushButton{background-color: rgb(49,154,144);color:rgb(253,254,255);}");  //设置清零按钮的背景颜色和文本颜色
    ui->Clear->setShortcut(QKeySequence("Delete"));  //允许用键盘实现清零功能
    ui->Equal->setFixedSize(102,51);  //设置等号按钮固定大小
    ui->Equal->setStyleSheet("QPushButton{background-color: rgb(49,154,144);color:rgb(253,254,255);}");  //设置等号按钮的背景颜色和文本颜色
    ui->Equal->setShortcut(QKeySequence("Enter"));  //允许用键盘实现输入等号（求值）
    ui->ShiftLeft->setFixedSize(51,51);  //设置左移位按钮固定大小
    ui->ShiftLeft->setStyleSheet("QPushButton{background-color: rgb(251,158,143);color:rgb(253,254,255);}");  //设置左移位按钮的背景颜色和文本颜色
    ui->ShiftLeft->setShortcut(QKeySequence("Shift+9"));  //允许用键盘实现输入左移位
    ui->NOT->setFixedSize(51,51);  //设置非运算按钮固定大小
    ui->NOT->setStyleSheet("QPushButton{background-color: rgb(251,158,143);color:rgb(253,254,255);}");  //设置非运算按钮的背景颜色和文本颜色
    ui->NOT->setShortcut(QKeySequence("Ctrl+N"));  //允许用键盘实现输入非运算
    ui->AND->setFixedSize(51,51);  //设置与运算按钮固定大小
    ui->AND->setStyleSheet("QPushButton{background-color: rgb(251,158,143);color:rgb(253,254,255);}");  //设置与运算按钮的背景颜色和文本颜色
    ui->AND->setShortcut(QKeySequence("Ctrl+A"));  //允许用键盘实现输入与运算
    ui->ShiftRight->setFixedSize(51,51);  //设置右移位按钮固定大小
    ui->ShiftRight->setStyleSheet("QPushButton{background-color: rgb(251,158,143);color:rgb(253,254,255);}");  //设置右移位按钮的背景颜色和文本颜色
    ui->ShiftRight->setShortcut(QKeySequence("Shift+0"));  //允许用键盘实现输入右移位
    ui->OR->setFixedSize(51,51);  //设置或运算按钮固定大小
    ui->OR->setStyleSheet("QPushButton{background-color: rgb(251,158,143);color:rgb(253,254,255);}");  //设置或运算按钮的背景颜色和文本颜色
    ui->OR->setShortcut(QKeySequence("Ctrl+O"));  //允许用键盘实现输入或运算
}

PgCalculator::~PgCalculator()
{
    delete ui;
}

void PgCalculator::on_Num0_clicked()
{
    ui->lineEdit_10->insert("0");  //输入运算数0
}

void PgCalculator::on_Num1_clicked()
{
    ui->lineEdit_10->insert("1");  //输入运算数1
}

void PgCalculator::on_Num2_clicked()
{
    ui->lineEdit_10->insert("2");  //输入运算数2
}

void PgCalculator::on_Num3_clicked()
{
    ui->lineEdit_10->insert("3");  //输入运算数3
}

void PgCalculator::on_Num4_clicked()
{
    ui->lineEdit_10->insert("4");  //输入运算数4
}

void PgCalculator::on_Num5_clicked()
{
    ui->lineEdit_10->insert("5");  //输入运算数5
}

void PgCalculator::on_Num6_clicked()
{
    ui->lineEdit_10->insert("6");  //输入运算数6
}

void PgCalculator::on_Num7_clicked()
{
    ui->lineEdit_10->insert("7");  //输入运算数7
}

void PgCalculator::on_Num8_clicked()
{
    ui->lineEdit_10->insert("8");  //输入运算数8
}

void PgCalculator::on_Num9_clicked()
{
    ui->lineEdit_10->insert("9");  //输入运算数9
}

/*判断当前输入是否合法*/
bool PgCalculator::isInputLogical()
{
    QString a=ui->lineEdit_10->text();  //获取当前输入框里的内容
    QString b=a.back();  //获取输入框里最后一个字符
    double c=b.toDouble();  //将此字符转换成double类型
    if(b!='0'&&c==0)  //判断当前字符是否为运算符
    {
        return false;
    }
    return true;
}

/*清零符号的输入*/
void PgCalculator::on_Clear_clicked()
{
    ui->lineEdit_10->clear();
    ui->lineEdit_2->clear();
    ui->lineEdit_8->clear();
    ui->lineEdit_16->clear();  //实现计算器清零功能
}

/*退格符号的输入*/
void PgCalculator::on_Back_clicked()
{
    QString contents=ui->lineEdit_10->text();  //获取当前文本内容
    int strlens=contents.length();  //计算文本字符串长度
    if(strlens>0)  //判断当前输入框内是否文本
    {
        contents.chop(1);  //删除最后一个字符
        ui->lineEdit_10->setText(contents);  //更新文本内容
    }
}

/*数值转换函数*/
QString PgCalculator::numConversion(long long x,int n)
{
    stack<long long> s;  //开辟存储进制转换结果的栈
    long long mid=x/n;  //
    QString res;  //存储最终转换结果的字符串
    while(mid!=0)  //循环处理，直至mid=0
    {
        s.push(x-mid*n);  //把每次得到的余数入栈
        x=mid;  //更新被除数
        mid=x/n;  //继续进行短除法
    }
    s.push(x-mid*n);  //将最后一个余数入栈
    while(!s.empty())  //判断栈是否非空
    {
        QString a=QString::number(s.top());  //取出栈顶元素，用字符串类型存储
        if(n==2||n==8)
        {
            res.append(a);  //插入到转换结果的字符串中
        }
        else
        {
            if(s.top()>=10)  //处理十六进制的特殊情况
            {
                if(s.top()==10)
                {
                    res.append("A");
                }
                else if(s.top()==11)
                {
                    res.append("B");
                }
                else if(s.top()==12)
                {
                    res.append("C");
                }
                else if(s.top()==13)
                {
                    res.append("D");
                }
                else if(s.top()==14)
                {
                    res.append("E");
                }
                else
                {
                    res.append("F");
                }
            }
            else
            {
                res.append(a);  //插入到转换结果的字符串中
            }
        }
        s.pop();  //弹出栈顶元素
    }
    return res;
}

/*二进制转换为十进制的函数*/
long long BinToDec(QString p)
{
    long long res;
    for(int i=p.length()-1;i>=0;i--)
    {
        if(p[i]=='1')  //判断当前位置是否为1
        {
            res+=pow(2,p.length()-i-1);  //累加对应位置的二进制中的权重
        }
    }
    return res;
}

/*实现相与运算的函数*/
void PgCalculator::AND(QString a,QString b,int len)
{
    for(int i=0;i<a.length();i++)  //逐位相与
    {
        if(a[i]=='1'&&b[i]=='1')
        {
            a[i]='1';
        }
        else
        {
            a[i]='0';
        }
    }
    ui->lineEdit_2->setText(a);  //输出二进制答案
    long long e=BinToDec(a);  //将二进制转换成十进制
    QString e_=QString::number(e);
    ui->lineEdit_10->setText(e_);  //输出十进制答案
    ui->lineEdit_8->setText(numConversion(e,8));  //将十进制转换成八进制，并输出答案
    ui->lineEdit_16->setText(numConversion(e,16));  //将十进制转换成十六进制，并输出答案
}

/*实现相或运算的函数*/
void PgCalculator::OR(QString a,QString b,int len)
{
    for(int i=0;i<a.length();i++)  //逐位相或
    {
        if(a[i]=='0'&&b[i]=='0')
        {
            a[i]='0';
        }
        else
        {
            a[i]='1';
        }
    }
    ui->lineEdit_2->setText(a);  //输出二进制答案
    long long e=BinToDec(a);  //将二进制转换成十进制
    QString e_=QString::number(e);
    ui->lineEdit_10->setText(e_);  //输出十进制答案
    ui->lineEdit_8->setText(numConversion(e,8));  //将十进制转换成八进制，并输出答案
    ui->lineEdit_16->setText(numConversion(e,16));  //将十进制转换成十六进制，并输出答案
}

/*实现左移、右移的函数*/
void PgCalculator::shiftBitByBit(QString ori,int n,bool dir)
{
    if(dir)  //实现逐位左移
    {
        long long a=ori.toLongLong();
        a*=pow(2,n);
        ori=QString::number(a);
        ui->lineEdit_2->setText(numConversion(a,2));  //输出二进制答案
        ui->lineEdit_8->setText(numConversion(a,8));  //输出八进制答案
        ui->lineEdit_16->setText(numConversion(a,16));  //输出十六进制答案
        ui->lineEdit_10->setText(ori);  //输出十进制答案
    }
    else  //实现逐位右移
    {
        long long a=ori.toLongLong();
        QString temp=numConversion(a,2);  //将十进制字符串转换为二进制字符串
        if(n>=temp.length())  //判断移动位数是否大于二进制下字符串长度
        {
            ui->lineEdit_2->setText("0");  //输出二进制答案
            ui->lineEdit_8->setText("0");  //输出八进制答案
            ui->lineEdit_16->setText("0");  //输出十六进制答案
            ui->lineEdit_10->setText("0");  //输出十进制答案
        }
        else
        {
            temp.chop(n);  //删除后n位，等效于右移n位
            ui->lineEdit_2->setText(temp);  //输出二进制答案
            long long mid=BinToDec(temp);  //将二进制字符串转换为十进制数字
            ui->lineEdit_10->setText(QString::number(mid));  //输出十进制答案
            ui->lineEdit_8->setText(numConversion(mid,8));  //输出八进制答案
            ui->lineEdit_16->setText(numConversion(mid,16));  //输出十六进制答案
        }
    }
}

/*等号取值的槽函数*/
void PgCalculator::on_Equal_clicked()
{
    QString temp=ui->lineEdit_10->text();  //获取输入内容
    int tempLen=temp.length();  //计算输入字符串的长度
    int count=0;  //定义计数变量
    for(int i=0;i<tempLen;i++)
    {
        QString a=temp[i];
        double b=a.toDouble();  //将当前位置字符转换成double类型
        if(!(b==0&&a!="0"))
        {
            count++;  //统计输入中数字的个数
        }
    }
    if(count==tempLen)  //判断输入是否全为数字
    {
        long long num=temp.toLongLong();  //将字符串转换成数字类型
        ui->lineEdit_2->setText(numConversion(num,2));  //将十进制转换成二进制
        ui->lineEdit_8->setText(numConversion(num,8));  //将十进制转换成八进制
        ui->lineEdit_16->setText(numConversion(num,16));  //将十进制转换成十六进制
        return;
    }
    /*处理有运算符的情况*/
    QString judge=temp.back();
    if(judge.toInt()==0&&judge!='0')  //判断最后一位输入是否为运算符
    {
        QMessageBox::critical(this,"Programmer's Calculator","输入格式非法，请修改输入!",QMessageBox::Ok);  //设置输入失败的弹窗属性
        this->show();  //回到程序员计算器页面
        return;
    }
    if(temp.contains("~"))  //判断是否为NOT运算
    {
        int index=temp.indexOf("~");  //查找按位取反运算符的下标
        QString a=temp.mid(index+1,tempLen-index-1);  //截取操作数
        long long b=a.toLongLong();  //转换成数字类型
        temp=numConversion(b,2);  //输出二进制结果
        for(int i=0;i<temp.length();i++)  //逐位操作
        {
            if(temp[i]=='0')
            {
                temp[i]='1';  //0-->1
            }
            else
            {
                temp[i]='0';  //1-->0
            }
        }
        ui->lineEdit_2->setText(temp);  //输出运算后的答案
        ui->lineEdit_16->clear();  //清空十六进制文本框里的内容(按位取反默认只能在二进制中进行)
        ui->lineEdit_8->clear();  //清空八进制文本框里的内容(按位取反默认只能在二进制中进行)
    }
    else if(temp.contains("&"))  //判断是否为AND运算
    {
        int index=temp.indexOf("&");  //查找AND运算符的下标
        QString a=temp.mid(0,index);  //截取操作数
        QString b=temp.mid(index+1,tempLen-index-1);  //截取操作数
        long long c=a.toLongLong();  //转换成十进制数字类型
        long long d=b.toLongLong();  //转换成十进制数字类型
        a=numConversion(c,2);  //转换成二进制字符串
        b=numConversion(d,2);  //转换成二进制字符串
        if(a.length()>b.length())
        {
            int len=a.length()-b.length();  //确定补0的个数
            for(int i=0;i<len;i++)
            {
                b='0'+b;
            }
            AND(a,b,a.length());  //调用求与运算的函数
        }
        else if(a.length()==b.length())  //处理两个字符串长度相等的情况
        {
            AND(a,b,a.length());  //调用求与运算的函数
        }
        else
        {
            int len=b.length()-a.length();  //确定补0的个数
            for(int i=0;i<len;i++)
            {
                a='0'+a;
            }
            AND(a,b,b.length());  //调用求与运算的函数
        }
    }
    else if(temp.contains("|"))
    {
        int index=temp.indexOf("|");  //查找OR运算符的下标
        QString a=temp.mid(0,index);  //截取操作数
        QString b=temp.mid(index+1,tempLen-index-1);  //截取操作数
        long long c=a.toLongLong();  //转换成十进制数字类型
        long long d=b.toLongLong();  //转换成十进制数字类型
        a=numConversion(c,2);  //转换成二进制字符串
        b=numConversion(d,2);  //转换成二进制字符串
        if(a.length()>b.length())
        {
            int len=a.length()-b.length();  //确定补0的个数
            for(int i=0;i<len;i++)
            {
                b='0'+b;
            }
            OR(a,b,a.length());  //调用求或运算的函数
        }
        else if(a.length()==b.length())  //处理两个字符串长度相等的情况
        {
            OR(a,b,a.length());  //调用求或运算的函数
        }
        else
        {
            int len=b.length()-a.length();  //确定补0的个数
            for(int i=0;i<len;i++)
            {
                a='0'+a;
            }
            OR(a,b,b.length());  //调用求或运算的函数
        }
    }
    else if(temp.contains("<<"))
    {
        int index=temp.indexOf("<<");  //查找<<运算符的下标
        QString a=temp.mid(0,index);  //截取操作数1
        QString b=temp.mid(index+2,tempLen-index-2);  //截取操作数2
        int d=b.toInt();  //转换成十进制数字类型
        shiftBitByBit(a,d,true);  //调用左移函数
    }
    else
    {
        int index=temp.indexOf(">>");  //查找>>运算符的下标
        QString a=temp.mid(0,index);  //截取操作数1
        QString b=temp.mid(index+2,tempLen-index-2);  //截取操作数2
        int d=b.toInt();  //转换成十进制数字类型
        shiftBitByBit(a,d,false);  //调用右移函数
    }
}

/*输入AND的槽函数*/
void PgCalculator::on_AND_clicked()
{
    ui->lineEdit_10->insert("&");  //输入运算符AND
}

/*输入OR的槽函数*/
void PgCalculator::on_OR_clicked()
{
    ui->lineEdit_10->insert("|");  //输入运算符OR
}

/*输入NOT的槽函数*/
void PgCalculator::on_NOT_clicked()
{
    ui->lineEdit_10->insert("~");  //输入运算符NOT
}

/*输入>>的槽函数*/
void PgCalculator::on_ShiftRight_clicked()
{
    ui->lineEdit_10->insert(">>");  //输入运算符>>
}

/*输入<<的槽函数*/
void PgCalculator::on_ShiftLeft_clicked()
{
    ui->lineEdit_10->insert("<<");  //输入运算符<<
}

